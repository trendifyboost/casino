# Routes package initialization
# This file makes the routes directory a Python package
